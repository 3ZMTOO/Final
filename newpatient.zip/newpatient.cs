﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Input;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using System.Net;

namespace WindowsFormsApp11
{
    public partial class newpatient : Form
    {
        public newpatient()
        {
            InitializeComponent();
            DisplayRec();
        }

        private void guna2TextBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void guna2Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void guna2Panel2_Paint(object sender, PaintEventArgs e)
        {

        }
        private void DisplayRec()
        {
            string conStr = ConfigurationManager.ConnectionStrings["db"].ToString();

            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                sqlcon.Open();
                string Query = "SELECT * FROM RACE";
                SqlDataAdapter sda = new SqlDataAdapter(Query, sqlcon);
                SqlCommandBuilder builder = new SqlCommandBuilder(sda);
                var ds = new DataSet();
                sda.Fill(ds);
                ReceDGV.DataSource = ds.Tables[0];
                
            }
        }

        private void guna2Button4_Click(object sender, EventArgs e)
        {
            string conStr = ConfigurationManager.ConnectionStrings["db"].ToString();

            using (SqlConnection sqlcon = new SqlConnection(conStr))
                if (Name.Text == "" || Nat.Text == "" || Email.Text ==""|| Phone.Text==""||Address.Text ==""||Gender.SelectedIndex==-1||date.Text==""||Weight.Text==""||Height.Text=="")
                {
                    MessageBox.Show("Missing Information");
                }
                else
                {
                    try
                    {
                        sqlcon.Open();

                        SqlCommand cmd = new SqlCommand("insert into RACE (name,natid,email,address,birth,gender,height,weight)values(@Nm,@Id,@e,@a,@b,@g,@h,@w)", sqlcon);

                        cmd.Parameters.AddWithValue("@Nm", Name.Text);
                        cmd.Parameters.AddWithValue("@Id", int.Parse(Nat.Text));
                        cmd.Parameters.AddWithValue("@e", Email.Text);
                        cmd.Parameters.AddWithValue("@a", Address.Text);
                        cmd.Parameters.AddWithValue("@b",  DateTime.Parse(date.Text));
                        cmd.Parameters.AddWithValue("@g", Gender.SelectedItem.ToString());
                        cmd.Parameters.AddWithValue("@h", Height.Text);
                        cmd.Parameters.AddWithValue("@w", Weight.Text);


                        cmd.ExecuteNonQuery();
                        MessageBox.Show("finally");


                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    finally
                    {
                        sqlcon.Close();
                        DisplayRec();
                    }
                }

        }

        private void newpatient_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'finialDataSet1.RACE' table. You can move, or remove it, as needed.
            this.rACETableAdapter.Fill(this.finialDataSet1.RACE);

        }

        private void guna2Button5_Click(object sender, EventArgs e)
        {
            string conStr = ConfigurationManager.ConnectionStrings["db"].ToString();

            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                if (key == 0)
                {
                    MessageBox.Show("Select The patient to Be Deleted");
                }
                else
                {
                    try
                    {
                        sqlcon.Open();
                        SqlCommand cmd = new SqlCommand("Delete from RACE where natid=@Rkey ", sqlcon);
                        cmd.Parameters.AddWithValue("@Rkey", key);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Receptionist Deleted");


                        DisplayRec();

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    finally
                    {
                        sqlcon.Close();
                    }
                }
            }
        }
        int key = 0;
        private void ReceDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            Name.Text = ReceDGV.SelectedRows[0].Cells[1].Value.ToString();
            date.Text = ReceDGV.SelectedRows[0].Cells[2].Value.ToString();
            Address.Text = ReceDGV.SelectedRows[0].Cells[3].Value.ToString();
            Email.Text = ReceDGV.SelectedRows[0].Cells[4].Value.ToString();
            Gender.SelectedItem = ReceDGV.SelectedRows[0].Cells[5].Value.ToString();
            Nat.Text = ReceDGV.SelectedRows[0].Cells[6].Value.ToString();
            Height.Text = ReceDGV.SelectedRows[0].Cells[7].Value.ToString();
            Weight.Text = ReceDGV.SelectedRows[0].Cells[8].Value.ToString();







            // Set the key variable to the value of the first cell in the clicked row
            key = Convert.ToInt32(ReceDGV.SelectedRows[0].Cells[0].Value.ToString());

        }

        private void guna2Button6_Click(object sender, EventArgs e)
        {
            string conStr = ConfigurationManager.ConnectionStrings["db"].ToString();

            using (SqlConnection sqlcon = new SqlConnection(conStr))
                if (Name.Text == "" || Nat.Text == "" || Email.Text == "" || Phone.Text == "" || Address.Text == "" || Gender.SelectedIndex == -1 || date.Text == "" || Weight.Text == "" || Height.Text == "")
                {
                    MessageBox.Show("Missing Information");
                }
                else
                {
                    try
                    {
                        sqlcon.Open();

                        SqlCommand cmd = new SqlCommand("update RACE set name=@Nm,natid=@Id,email=@e,address=@a,birth=@b,gender=@g,height=@h,weight)values(@Nm,@Id,@e,@a,@b,@g,@h,@w)", sqlcon);

                        cmd.Parameters.AddWithValue("@Nm", Name.Text);
                        cmd.Parameters.AddWithValue("@Id", int.Parse(Nat.Text));
                        cmd.Parameters.AddWithValue("@e", Email.Text);
                        cmd.Parameters.AddWithValue("@a", Address.Text);
                        cmd.Parameters.AddWithValue("@b", DateTime.Parse(date.Text));
                        cmd.Parameters.AddWithValue("@g", Gender.SelectedItem.ToString());
                        cmd.Parameters.AddWithValue("@h", Height.Text);
                        cmd.Parameters.AddWithValue("@w", Weight.Text);


                        cmd.ExecuteNonQuery();
                        MessageBox.Show("finally");


                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    finally
                    {
                        sqlcon.Close();
                        DisplayRec();
                    }
                }



        }

        private void name_TextChanged(object sender, EventArgs e)
        {

        }

        private void gender_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void guna2Button7_Click(object sender, EventArgs e)
        {
            OpenFileDialog r = new OpenFileDialog();

            r.Filter = "Images Files: |*.jpg;* .gif;* .BMP; *.PNG";
            if (r.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image = Image.FromFile(r.FileName);
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
