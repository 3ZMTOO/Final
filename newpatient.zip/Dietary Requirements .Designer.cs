﻿namespace WindowsFormsApp11
{
    partial class Dietary_Requirements
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.guna2TextBox1 = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2TextBox2 = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2TextBox5 = new Guna.UI2.WinForms.Guna2TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.guna2DateTimePicker1 = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.guna2ControlBox4 = new Guna.UI2.WinForms.Guna2ControlBox();
            this.guna2ControlBox5 = new Guna.UI2.WinForms.Guna2ControlBox();
            this.guna2ControlBox6 = new Guna.UI2.WinForms.Guna2ControlBox();
            this.label3 = new System.Windows.Forms.Label();
            this.guna2CheckBox1 = new Guna.UI2.WinForms.Guna2CheckBox();
            this.guna2CheckBox2 = new Guna.UI2.WinForms.Guna2CheckBox();
            this.guna2CheckBox3 = new Guna.UI2.WinForms.Guna2CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.guna2CheckBox4 = new Guna.UI2.WinForms.Guna2CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.guna2CheckBox5 = new Guna.UI2.WinForms.Guna2CheckBox();
            this.guna2CheckBox6 = new Guna.UI2.WinForms.Guna2CheckBox();
            this.guna2CheckBox7 = new Guna.UI2.WinForms.Guna2CheckBox();
            this.guna2CheckBox8 = new Guna.UI2.WinForms.Guna2CheckBox();
            this.guna2CheckBox9 = new Guna.UI2.WinForms.Guna2CheckBox();
            this.guna2CheckBox10 = new Guna.UI2.WinForms.Guna2CheckBox();
            this.guna2CheckBox11 = new Guna.UI2.WinForms.Guna2CheckBox();
            this.guna2TextBox3 = new Guna.UI2.WinForms.Guna2TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.guna2CheckBox12 = new Guna.UI2.WinForms.Guna2CheckBox();
            this.guna2CheckBox13 = new Guna.UI2.WinForms.Guna2CheckBox();
            this.guna2CheckBox14 = new Guna.UI2.WinForms.Guna2CheckBox();
            this.guna2CheckBox15 = new Guna.UI2.WinForms.Guna2CheckBox();
            this.guna2CheckBox16 = new Guna.UI2.WinForms.Guna2CheckBox();
            this.guna2CheckBox17 = new Guna.UI2.WinForms.Guna2CheckBox();
            this.guna2CheckBox18 = new Guna.UI2.WinForms.Guna2CheckBox();
            this.guna2CheckBox19 = new Guna.UI2.WinForms.Guna2CheckBox();
            this.guna2CheckBox20 = new Guna.UI2.WinForms.Guna2CheckBox();
            this.guna2CheckBox21 = new Guna.UI2.WinForms.Guna2CheckBox();
            this.guna2CheckBox22 = new Guna.UI2.WinForms.Guna2CheckBox();
            this.guna2CheckBox23 = new Guna.UI2.WinForms.Guna2CheckBox();
            this.guna2CheckBox24 = new Guna.UI2.WinForms.Guna2CheckBox();
            this.guna2CheckBox25 = new Guna.UI2.WinForms.Guna2CheckBox();
            this.guna2CheckBox26 = new Guna.UI2.WinForms.Guna2CheckBox();
            this.guna2TextBox4 = new Guna.UI2.WinForms.Guna2TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.guna2CheckBox27 = new Guna.UI2.WinForms.Guna2CheckBox();
            this.guna2CheckBox28 = new Guna.UI2.WinForms.Guna2CheckBox();
            this.guna2CheckBox29 = new Guna.UI2.WinForms.Guna2CheckBox();
            this.label8 = new System.Windows.Forms.Label();
            this.guna2DateTimePicker2 = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.guna2CheckBox30 = new Guna.UI2.WinForms.Guna2CheckBox();
            this.guna2CheckBox31 = new Guna.UI2.WinForms.Guna2CheckBox();
            this.guna2CheckBox32 = new Guna.UI2.WinForms.Guna2CheckBox();
            this.guna2CheckBox33 = new Guna.UI2.WinForms.Guna2CheckBox();
            this.guna2TextBox6 = new Guna.UI2.WinForms.Guna2TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.guna2CheckBox34 = new Guna.UI2.WinForms.Guna2CheckBox();
            this.guna2CheckBox35 = new Guna.UI2.WinForms.Guna2CheckBox();
            this.guna2CheckBox36 = new Guna.UI2.WinForms.Guna2CheckBox();
            this.guna2CheckBox37 = new Guna.UI2.WinForms.Guna2CheckBox();
            this.label11 = new System.Windows.Forms.Label();
            this.guna2TextBox8 = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2Button7 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2TextBox1
            // 
            this.guna2TextBox1.BorderThickness = 3;
            this.guna2TextBox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox1.DefaultText = "";
            this.guna2TextBox1.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox1.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox1.FillColor = System.Drawing.Color.WhiteSmoke;
            this.guna2TextBox1.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2TextBox1.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox1.Location = new System.Drawing.Point(12, 84);
            this.guna2TextBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.guna2TextBox1.Name = "guna2TextBox1";
            this.guna2TextBox1.PasswordChar = '\0';
            this.guna2TextBox1.PlaceholderForeColor = System.Drawing.Color.Black;
            this.guna2TextBox1.PlaceholderText = "Name";
            this.guna2TextBox1.SelectedText = "";
            this.guna2TextBox1.Size = new System.Drawing.Size(215, 43);
            this.guna2TextBox1.TabIndex = 7;
            // 
            // guna2TextBox2
            // 
            this.guna2TextBox2.BorderThickness = 3;
            this.guna2TextBox2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox2.DefaultText = "";
            this.guna2TextBox2.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox2.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox2.FillColor = System.Drawing.Color.WhiteSmoke;
            this.guna2TextBox2.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2TextBox2.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox2.Location = new System.Drawing.Point(295, 84);
            this.guna2TextBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.guna2TextBox2.Name = "guna2TextBox2";
            this.guna2TextBox2.PasswordChar = '\0';
            this.guna2TextBox2.PlaceholderForeColor = System.Drawing.Color.Black;
            this.guna2TextBox2.PlaceholderText = "Email";
            this.guna2TextBox2.SelectedText = "";
            this.guna2TextBox2.Size = new System.Drawing.Size(407, 43);
            this.guna2TextBox2.TabIndex = 8;
            // 
            // guna2TextBox5
            // 
            this.guna2TextBox5.BorderThickness = 3;
            this.guna2TextBox5.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox5.DefaultText = "";
            this.guna2TextBox5.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox5.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox5.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox5.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox5.FillColor = System.Drawing.Color.WhiteSmoke;
            this.guna2TextBox5.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox5.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2TextBox5.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox5.Location = new System.Drawing.Point(411, 134);
            this.guna2TextBox5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.guna2TextBox5.Name = "guna2TextBox5";
            this.guna2TextBox5.PasswordChar = '\0';
            this.guna2TextBox5.PlaceholderForeColor = System.Drawing.Color.Black;
            this.guna2TextBox5.PlaceholderText = "Phone Number";
            this.guna2TextBox5.SelectedText = "";
            this.guna2TextBox5.Size = new System.Drawing.Size(215, 43);
            this.guna2TextBox5.TabIndex = 11;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Monotype Corsiva", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(31, 141);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(95, 45);
            this.label2.TabIndex = 12;
            this.label2.Text = "Birth";
            // 
            // guna2DateTimePicker1
            // 
            this.guna2DateTimePicker1.Checked = true;
            this.guna2DateTimePicker1.FillColor = System.Drawing.Color.Silver;
            this.guna2DateTimePicker1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2DateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.guna2DateTimePicker1.Location = new System.Drawing.Point(179, 141);
            this.guna2DateTimePicker1.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.guna2DateTimePicker1.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.guna2DateTimePicker1.Name = "guna2DateTimePicker1";
            this.guna2DateTimePicker1.Size = new System.Drawing.Size(200, 36);
            this.guna2DateTimePicker1.TabIndex = 13;
            this.guna2DateTimePicker1.Value = new System.DateTime(2023, 1, 7, 10, 19, 25, 856);
            // 
            // comboBox1
            // 
            this.comboBox1.BackColor = System.Drawing.Color.DarkGray;
            this.comboBox1.ForeColor = System.Drawing.SystemColors.MenuText;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Female",
            "Male"});
            this.comboBox1.Location = new System.Drawing.Point(640, 141);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 24);
            this.comboBox1.TabIndex = 14;
            this.comboBox1.Text = "Gender";
            // 
            // guna2Panel2
            // 
            this.guna2Panel2.Controls.Add(this.label1);
            this.guna2Panel2.Controls.Add(this.guna2ControlBox4);
            this.guna2Panel2.Controls.Add(this.guna2ControlBox5);
            this.guna2Panel2.Controls.Add(this.guna2ControlBox6);
            this.guna2Panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2Panel2.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel2.Name = "guna2Panel2";
            this.guna2Panel2.Size = new System.Drawing.Size(1942, 57);
            this.guna2Panel2.TabIndex = 15;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Monotype Corsiva", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(468, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(465, 45);
            this.label1.TabIndex = 4;
            this.label1.Text = "Dietary Requirements Template";
            // 
            // guna2ControlBox4
            // 
            this.guna2ControlBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ControlBox4.BackColor = System.Drawing.Color.Transparent;
            this.guna2ControlBox4.FillColor = System.Drawing.Color.Transparent;
            this.guna2ControlBox4.IconColor = System.Drawing.Color.DarkRed;
            this.guna2ControlBox4.Location = new System.Drawing.Point(1897, 0);
            this.guna2ControlBox4.Name = "guna2ControlBox4";
            this.guna2ControlBox4.Size = new System.Drawing.Size(45, 29);
            this.guna2ControlBox4.TabIndex = 1;
            // 
            // guna2ControlBox5
            // 
            this.guna2ControlBox5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ControlBox5.BackColor = System.Drawing.Color.Transparent;
            this.guna2ControlBox5.ControlBoxType = Guna.UI2.WinForms.Enums.ControlBoxType.MaximizeBox;
            this.guna2ControlBox5.FillColor = System.Drawing.Color.Transparent;
            this.guna2ControlBox5.IconColor = System.Drawing.Color.DarkRed;
            this.guna2ControlBox5.Location = new System.Drawing.Point(1859, 0);
            this.guna2ControlBox5.Name = "guna2ControlBox5";
            this.guna2ControlBox5.Size = new System.Drawing.Size(45, 29);
            this.guna2ControlBox5.TabIndex = 3;
            // 
            // guna2ControlBox6
            // 
            this.guna2ControlBox6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ControlBox6.BackColor = System.Drawing.Color.Transparent;
            this.guna2ControlBox6.ControlBoxType = Guna.UI2.WinForms.Enums.ControlBoxType.MinimizeBox;
            this.guna2ControlBox6.FillColor = System.Drawing.Color.Transparent;
            this.guna2ControlBox6.IconColor = System.Drawing.Color.DarkRed;
            this.guna2ControlBox6.Location = new System.Drawing.Point(1819, 0);
            this.guna2ControlBox6.Name = "guna2ControlBox6";
            this.guna2ControlBox6.Size = new System.Drawing.Size(45, 29);
            this.guna2ControlBox6.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Monotype Corsiva", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(4, 206);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(697, 45);
            this.label3.TabIndex = 16;
            this.label3.Text = "Please select all of them below that describe you";
            // 
            // guna2CheckBox1
            // 
            this.guna2CheckBox1.AutoSize = true;
            this.guna2CheckBox1.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox1.CheckedState.BorderRadius = 0;
            this.guna2CheckBox1.CheckedState.BorderThickness = 0;
            this.guna2CheckBox1.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.guna2CheckBox1.Location = new System.Drawing.Point(28, 254);
            this.guna2CheckBox1.Name = "guna2CheckBox1";
            this.guna2CheckBox1.Size = new System.Drawing.Size(97, 20);
            this.guna2CheckBox1.TabIndex = 17;
            this.guna2CheckBox1.Text = "I am Vegan";
            this.guna2CheckBox1.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CheckBox1.UncheckedState.BorderRadius = 0;
            this.guna2CheckBox1.UncheckedState.BorderThickness = 0;
            this.guna2CheckBox1.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // guna2CheckBox2
            // 
            this.guna2CheckBox2.AutoSize = true;
            this.guna2CheckBox2.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox2.CheckedState.BorderRadius = 0;
            this.guna2CheckBox2.CheckedState.BorderThickness = 0;
            this.guna2CheckBox2.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.guna2CheckBox2.Location = new System.Drawing.Point(28, 289);
            this.guna2CheckBox2.Name = "guna2CheckBox2";
            this.guna2CheckBox2.Size = new System.Drawing.Size(123, 20);
            this.guna2CheckBox2.TabIndex = 18;
            this.guna2CheckBox2.Text = "I am Vegetarian";
            this.guna2CheckBox2.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CheckBox2.UncheckedState.BorderRadius = 0;
            this.guna2CheckBox2.UncheckedState.BorderThickness = 0;
            this.guna2CheckBox2.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // guna2CheckBox3
            // 
            this.guna2CheckBox3.AutoSize = true;
            this.guna2CheckBox3.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox3.CheckedState.BorderRadius = 0;
            this.guna2CheckBox3.CheckedState.BorderThickness = 0;
            this.guna2CheckBox3.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.guna2CheckBox3.Location = new System.Drawing.Point(28, 325);
            this.guna2CheckBox3.Name = "guna2CheckBox3";
            this.guna2CheckBox3.Size = new System.Drawing.Size(150, 20);
            this.guna2CheckBox3.TabIndex = 19;
            this.guna2CheckBox3.Text = "I have food allergies";
            this.guna2CheckBox3.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CheckBox3.UncheckedState.BorderRadius = 0;
            this.guna2CheckBox3.UncheckedState.BorderThickness = 0;
            this.guna2CheckBox3.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Monotype Corsiva", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(20, 357);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(110, 45);
            this.label4.TabIndex = 20;
            this.label4.Text = "Vegan";
            // 
            // guna2CheckBox4
            // 
            this.guna2CheckBox4.AutoSize = true;
            this.guna2CheckBox4.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox4.CheckedState.BorderRadius = 0;
            this.guna2CheckBox4.CheckedState.BorderThickness = 0;
            this.guna2CheckBox4.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.guna2CheckBox4.Location = new System.Drawing.Point(154, 372);
            this.guna2CheckBox4.Name = "guna2CheckBox4";
            this.guna2CheckBox4.Size = new System.Drawing.Size(257, 20);
            this.guna2CheckBox4.TabIndex = 21;
            this.guna2CheckBox4.Text = "I eat only plant food and plant products";
            this.guna2CheckBox4.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CheckBox4.UncheckedState.BorderRadius = 0;
            this.guna2CheckBox4.UncheckedState.BorderThickness = 0;
            this.guna2CheckBox4.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Monotype Corsiva", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(20, 402);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(176, 45);
            this.label5.TabIndex = 22;
            this.label5.Text = "Vegaterian";
            // 
            // guna2CheckBox5
            // 
            this.guna2CheckBox5.AutoSize = true;
            this.guna2CheckBox5.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox5.CheckedState.BorderRadius = 0;
            this.guna2CheckBox5.CheckedState.BorderThickness = 0;
            this.guna2CheckBox5.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.guna2CheckBox5.Location = new System.Drawing.Point(207, 425);
            this.guna2CheckBox5.Name = "guna2CheckBox5";
            this.guna2CheckBox5.Size = new System.Drawing.Size(109, 20);
            this.guna2CheckBox5.TabIndex = 23;
            this.guna2CheckBox5.Text = "No Red Meat";
            this.guna2CheckBox5.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CheckBox5.UncheckedState.BorderRadius = 0;
            this.guna2CheckBox5.UncheckedState.BorderThickness = 0;
            this.guna2CheckBox5.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // guna2CheckBox6
            // 
            this.guna2CheckBox6.AutoSize = true;
            this.guna2CheckBox6.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox6.CheckedState.BorderRadius = 0;
            this.guna2CheckBox6.CheckedState.BorderThickness = 0;
            this.guna2CheckBox6.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.guna2CheckBox6.Location = new System.Drawing.Point(207, 451);
            this.guna2CheckBox6.Name = "guna2CheckBox6";
            this.guna2CheckBox6.Size = new System.Drawing.Size(98, 20);
            this.guna2CheckBox6.TabIndex = 24;
            this.guna2CheckBox6.Text = "No Chicken";
            this.guna2CheckBox6.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CheckBox6.UncheckedState.BorderRadius = 0;
            this.guna2CheckBox6.UncheckedState.BorderThickness = 0;
            this.guna2CheckBox6.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // guna2CheckBox7
            // 
            this.guna2CheckBox7.AutoSize = true;
            this.guna2CheckBox7.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox7.CheckedState.BorderRadius = 0;
            this.guna2CheckBox7.CheckedState.BorderThickness = 0;
            this.guna2CheckBox7.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.guna2CheckBox7.Location = new System.Drawing.Point(207, 477);
            this.guna2CheckBox7.Name = "guna2CheckBox7";
            this.guna2CheckBox7.Size = new System.Drawing.Size(75, 20);
            this.guna2CheckBox7.TabIndex = 25;
            this.guna2CheckBox7.Text = "No Fish";
            this.guna2CheckBox7.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CheckBox7.UncheckedState.BorderRadius = 0;
            this.guna2CheckBox7.UncheckedState.BorderThickness = 0;
            this.guna2CheckBox7.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // guna2CheckBox8
            // 
            this.guna2CheckBox8.AutoSize = true;
            this.guna2CheckBox8.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox8.CheckedState.BorderRadius = 0;
            this.guna2CheckBox8.CheckedState.BorderThickness = 0;
            this.guna2CheckBox8.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.guna2CheckBox8.Location = new System.Drawing.Point(207, 503);
            this.guna2CheckBox8.Name = "guna2CheckBox8";
            this.guna2CheckBox8.Size = new System.Drawing.Size(82, 20);
            this.guna2CheckBox8.TabIndex = 26;
            this.guna2CheckBox8.Text = "No Eggs";
            this.guna2CheckBox8.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CheckBox8.UncheckedState.BorderRadius = 0;
            this.guna2CheckBox8.UncheckedState.BorderThickness = 0;
            this.guna2CheckBox8.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // guna2CheckBox9
            // 
            this.guna2CheckBox9.AutoSize = true;
            this.guna2CheckBox9.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox9.CheckedState.BorderRadius = 0;
            this.guna2CheckBox9.CheckedState.BorderThickness = 0;
            this.guna2CheckBox9.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.guna2CheckBox9.Location = new System.Drawing.Point(207, 529);
            this.guna2CheckBox9.Name = "guna2CheckBox9";
            this.guna2CheckBox9.Size = new System.Drawing.Size(78, 20);
            this.guna2CheckBox9.TabIndex = 27;
            this.guna2CheckBox9.Text = "No Pork";
            this.guna2CheckBox9.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CheckBox9.UncheckedState.BorderRadius = 0;
            this.guna2CheckBox9.UncheckedState.BorderThickness = 0;
            this.guna2CheckBox9.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // guna2CheckBox10
            // 
            this.guna2CheckBox10.AutoSize = true;
            this.guna2CheckBox10.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox10.CheckedState.BorderRadius = 0;
            this.guna2CheckBox10.CheckedState.BorderThickness = 0;
            this.guna2CheckBox10.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox10.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.guna2CheckBox10.Location = new System.Drawing.Point(207, 555);
            this.guna2CheckBox10.Name = "guna2CheckBox10";
            this.guna2CheckBox10.Size = new System.Drawing.Size(138, 20);
            this.guna2CheckBox10.TabIndex = 28;
            this.guna2CheckBox10.Text = "No Dairy Products";
            this.guna2CheckBox10.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CheckBox10.UncheckedState.BorderRadius = 0;
            this.guna2CheckBox10.UncheckedState.BorderThickness = 0;
            this.guna2CheckBox10.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // guna2CheckBox11
            // 
            this.guna2CheckBox11.AutoSize = true;
            this.guna2CheckBox11.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox11.CheckedState.BorderRadius = 0;
            this.guna2CheckBox11.CheckedState.BorderThickness = 0;
            this.guna2CheckBox11.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox11.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.guna2CheckBox11.Location = new System.Drawing.Point(207, 581);
            this.guna2CheckBox11.Name = "guna2CheckBox11";
            this.guna2CheckBox11.Size = new System.Drawing.Size(18, 17);
            this.guna2CheckBox11.TabIndex = 29;
            this.guna2CheckBox11.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CheckBox11.UncheckedState.BorderRadius = 0;
            this.guna2CheckBox11.UncheckedState.BorderThickness = 0;
            this.guna2CheckBox11.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // guna2TextBox3
            // 
            this.guna2TextBox3.BorderThickness = 3;
            this.guna2TextBox3.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox3.DefaultText = "";
            this.guna2TextBox3.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox3.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox3.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox3.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox3.FillColor = System.Drawing.Color.WhiteSmoke;
            this.guna2TextBox3.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2TextBox3.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox3.Location = new System.Drawing.Point(231, 581);
            this.guna2TextBox3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.guna2TextBox3.Name = "guna2TextBox3";
            this.guna2TextBox3.PasswordChar = '\0';
            this.guna2TextBox3.PlaceholderForeColor = System.Drawing.Color.Black;
            this.guna2TextBox3.PlaceholderText = "Other";
            this.guna2TextBox3.SelectedText = "";
            this.guna2TextBox3.Size = new System.Drawing.Size(215, 43);
            this.guna2TextBox3.TabIndex = 30;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Monotype Corsiva", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(31, 643);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(223, 45);
            this.label6.TabIndex = 31;
            this.label6.Text = "Food Allergies";
            // 
            // guna2CheckBox12
            // 
            this.guna2CheckBox12.AutoSize = true;
            this.guna2CheckBox12.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox12.CheckedState.BorderRadius = 0;
            this.guna2CheckBox12.CheckedState.BorderThickness = 0;
            this.guna2CheckBox12.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox12.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.guna2CheckBox12.Location = new System.Drawing.Point(260, 658);
            this.guna2CheckBox12.Name = "guna2CheckBox12";
            this.guna2CheckBox12.Size = new System.Drawing.Size(78, 20);
            this.guna2CheckBox12.TabIndex = 32;
            this.guna2CheckBox12.Text = "Peanuts";
            this.guna2CheckBox12.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CheckBox12.UncheckedState.BorderRadius = 0;
            this.guna2CheckBox12.UncheckedState.BorderThickness = 0;
            this.guna2CheckBox12.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // guna2CheckBox13
            // 
            this.guna2CheckBox13.AutoSize = true;
            this.guna2CheckBox13.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox13.CheckedState.BorderRadius = 0;
            this.guna2CheckBox13.CheckedState.BorderThickness = 0;
            this.guna2CheckBox13.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox13.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.guna2CheckBox13.Location = new System.Drawing.Point(260, 1022);
            this.guna2CheckBox13.Name = "guna2CheckBox13";
            this.guna2CheckBox13.Size = new System.Drawing.Size(18, 17);
            this.guna2CheckBox13.TabIndex = 33;
            this.guna2CheckBox13.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CheckBox13.UncheckedState.BorderRadius = 0;
            this.guna2CheckBox13.UncheckedState.BorderThickness = 0;
            this.guna2CheckBox13.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // guna2CheckBox14
            // 
            this.guna2CheckBox14.AutoSize = true;
            this.guna2CheckBox14.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox14.CheckedState.BorderRadius = 0;
            this.guna2CheckBox14.CheckedState.BorderThickness = 0;
            this.guna2CheckBox14.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox14.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.guna2CheckBox14.Location = new System.Drawing.Point(260, 996);
            this.guna2CheckBox14.Name = "guna2CheckBox14";
            this.guna2CheckBox14.Size = new System.Drawing.Size(80, 20);
            this.guna2CheckBox14.TabIndex = 34;
            this.guna2CheckBox14.Text = " Mustard";
            this.guna2CheckBox14.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CheckBox14.UncheckedState.BorderRadius = 0;
            this.guna2CheckBox14.UncheckedState.BorderThickness = 0;
            this.guna2CheckBox14.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // guna2CheckBox15
            // 
            this.guna2CheckBox15.AutoSize = true;
            this.guna2CheckBox15.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox15.CheckedState.BorderRadius = 0;
            this.guna2CheckBox15.CheckedState.BorderThickness = 0;
            this.guna2CheckBox15.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox15.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.guna2CheckBox15.Location = new System.Drawing.Point(260, 970);
            this.guna2CheckBox15.Name = "guna2CheckBox15";
            this.guna2CheckBox15.Size = new System.Drawing.Size(68, 20);
            this.guna2CheckBox15.TabIndex = 35;
            this.guna2CheckBox15.Text = "Lupins";
            this.guna2CheckBox15.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CheckBox15.UncheckedState.BorderRadius = 0;
            this.guna2CheckBox15.UncheckedState.BorderThickness = 0;
            this.guna2CheckBox15.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // guna2CheckBox16
            // 
            this.guna2CheckBox16.AutoSize = true;
            this.guna2CheckBox16.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox16.CheckedState.BorderRadius = 0;
            this.guna2CheckBox16.CheckedState.BorderThickness = 0;
            this.guna2CheckBox16.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox16.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.guna2CheckBox16.Location = new System.Drawing.Point(260, 944);
            this.guna2CheckBox16.Name = "guna2CheckBox16";
            this.guna2CheckBox16.Size = new System.Drawing.Size(65, 20);
            this.guna2CheckBox16.TabIndex = 36;
            this.guna2CheckBox16.Text = "Sulfite";
            this.guna2CheckBox16.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CheckBox16.UncheckedState.BorderRadius = 0;
            this.guna2CheckBox16.UncheckedState.BorderThickness = 0;
            this.guna2CheckBox16.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // guna2CheckBox17
            // 
            this.guna2CheckBox17.AutoSize = true;
            this.guna2CheckBox17.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox17.CheckedState.BorderRadius = 0;
            this.guna2CheckBox17.CheckedState.BorderThickness = 0;
            this.guna2CheckBox17.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox17.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.guna2CheckBox17.Location = new System.Drawing.Point(260, 918);
            this.guna2CheckBox17.Name = "guna2CheckBox17";
            this.guna2CheckBox17.Size = new System.Drawing.Size(67, 20);
            this.guna2CheckBox17.TabIndex = 37;
            this.guna2CheckBox17.Text = "Gluten";
            this.guna2CheckBox17.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CheckBox17.UncheckedState.BorderRadius = 0;
            this.guna2CheckBox17.UncheckedState.BorderThickness = 0;
            this.guna2CheckBox17.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // guna2CheckBox18
            // 
            this.guna2CheckBox18.AutoSize = true;
            this.guna2CheckBox18.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox18.CheckedState.BorderRadius = 0;
            this.guna2CheckBox18.CheckedState.BorderThickness = 0;
            this.guna2CheckBox18.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox18.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.guna2CheckBox18.Location = new System.Drawing.Point(260, 892);
            this.guna2CheckBox18.Name = "guna2CheckBox18";
            this.guna2CheckBox18.Size = new System.Drawing.Size(92, 20);
            this.guna2CheckBox18.TabIndex = 38;
            this.guna2CheckBox18.Text = "Mushroom";
            this.guna2CheckBox18.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CheckBox18.UncheckedState.BorderRadius = 0;
            this.guna2CheckBox18.UncheckedState.BorderThickness = 0;
            this.guna2CheckBox18.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // guna2CheckBox19
            // 
            this.guna2CheckBox19.AutoSize = true;
            this.guna2CheckBox19.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox19.CheckedState.BorderRadius = 0;
            this.guna2CheckBox19.CheckedState.BorderThickness = 0;
            this.guna2CheckBox19.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox19.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.guna2CheckBox19.Location = new System.Drawing.Point(260, 866);
            this.guna2CheckBox19.Name = "guna2CheckBox19";
            this.guna2CheckBox19.Size = new System.Drawing.Size(65, 20);
            this.guna2CheckBox19.TabIndex = 39;
            this.guna2CheckBox19.Text = "Sugar";
            this.guna2CheckBox19.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CheckBox19.UncheckedState.BorderRadius = 0;
            this.guna2CheckBox19.UncheckedState.BorderThickness = 0;
            this.guna2CheckBox19.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // guna2CheckBox20
            // 
            this.guna2CheckBox20.AutoSize = true;
            this.guna2CheckBox20.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox20.CheckedState.BorderRadius = 0;
            this.guna2CheckBox20.CheckedState.BorderThickness = 0;
            this.guna2CheckBox20.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox20.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.guna2CheckBox20.Location = new System.Drawing.Point(260, 840);
            this.guna2CheckBox20.Name = "guna2CheckBox20";
            this.guna2CheckBox20.Size = new System.Drawing.Size(265, 20);
            this.guna2CheckBox20.TabIndex = 40;
            this.guna2CheckBox20.Text = "Tree nuts(Walnuts,almonds,pecans etc)";
            this.guna2CheckBox20.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CheckBox20.UncheckedState.BorderRadius = 0;
            this.guna2CheckBox20.UncheckedState.BorderThickness = 0;
            this.guna2CheckBox20.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // guna2CheckBox21
            // 
            this.guna2CheckBox21.AutoSize = true;
            this.guna2CheckBox21.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox21.CheckedState.BorderRadius = 0;
            this.guna2CheckBox21.CheckedState.BorderThickness = 0;
            this.guna2CheckBox21.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox21.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.guna2CheckBox21.Location = new System.Drawing.Point(260, 814);
            this.guna2CheckBox21.Name = "guna2CheckBox21";
            this.guna2CheckBox21.Size = new System.Drawing.Size(76, 20);
            this.guna2CheckBox21.TabIndex = 41;
            this.guna2CheckBox21.Text = "Nut oills";
            this.guna2CheckBox21.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CheckBox21.UncheckedState.BorderRadius = 0;
            this.guna2CheckBox21.UncheckedState.BorderThickness = 0;
            this.guna2CheckBox21.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // guna2CheckBox22
            // 
            this.guna2CheckBox22.AutoSize = true;
            this.guna2CheckBox22.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox22.CheckedState.BorderRadius = 0;
            this.guna2CheckBox22.CheckedState.BorderThickness = 0;
            this.guna2CheckBox22.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox22.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.guna2CheckBox22.Location = new System.Drawing.Point(260, 788);
            this.guna2CheckBox22.Name = "guna2CheckBox22";
            this.guna2CheckBox22.Size = new System.Drawing.Size(53, 20);
            this.guna2CheckBox22.TabIndex = 42;
            this.guna2CheckBox22.Text = "Milk";
            this.guna2CheckBox22.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CheckBox22.UncheckedState.BorderRadius = 0;
            this.guna2CheckBox22.UncheckedState.BorderThickness = 0;
            this.guna2CheckBox22.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // guna2CheckBox23
            // 
            this.guna2CheckBox23.AutoSize = true;
            this.guna2CheckBox23.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox23.CheckedState.BorderRadius = 0;
            this.guna2CheckBox23.CheckedState.BorderThickness = 0;
            this.guna2CheckBox23.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox23.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.guna2CheckBox23.Location = new System.Drawing.Point(260, 762);
            this.guna2CheckBox23.Name = "guna2CheckBox23";
            this.guna2CheckBox23.Size = new System.Drawing.Size(108, 20);
            this.guna2CheckBox23.TabIndex = 43;
            this.guna2CheckBox23.Text = "Soy products";
            this.guna2CheckBox23.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CheckBox23.UncheckedState.BorderRadius = 0;
            this.guna2CheckBox23.UncheckedState.BorderThickness = 0;
            this.guna2CheckBox23.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // guna2CheckBox24
            // 
            this.guna2CheckBox24.AutoSize = true;
            this.guna2CheckBox24.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox24.CheckedState.BorderRadius = 0;
            this.guna2CheckBox24.CheckedState.BorderThickness = 0;
            this.guna2CheckBox24.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox24.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.guna2CheckBox24.Location = new System.Drawing.Point(260, 736);
            this.guna2CheckBox24.Name = "guna2CheckBox24";
            this.guna2CheckBox24.Size = new System.Drawing.Size(142, 20);
            this.guna2CheckBox24.TabIndex = 44;
            this.guna2CheckBox24.Text = "Peanut or nut butter";
            this.guna2CheckBox24.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CheckBox24.UncheckedState.BorderRadius = 0;
            this.guna2CheckBox24.UncheckedState.BorderThickness = 0;
            this.guna2CheckBox24.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // guna2CheckBox25
            // 
            this.guna2CheckBox25.AutoSize = true;
            this.guna2CheckBox25.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox25.CheckedState.BorderRadius = 0;
            this.guna2CheckBox25.CheckedState.BorderThickness = 0;
            this.guna2CheckBox25.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox25.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.guna2CheckBox25.Location = new System.Drawing.Point(260, 710);
            this.guna2CheckBox25.Name = "guna2CheckBox25";
            this.guna2CheckBox25.Size = new System.Drawing.Size(61, 20);
            this.guna2CheckBox25.TabIndex = 45;
            this.guna2CheckBox25.Text = "Eggs";
            this.guna2CheckBox25.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CheckBox25.UncheckedState.BorderRadius = 0;
            this.guna2CheckBox25.UncheckedState.BorderThickness = 0;
            this.guna2CheckBox25.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // guna2CheckBox26
            // 
            this.guna2CheckBox26.AutoSize = true;
            this.guna2CheckBox26.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox26.CheckedState.BorderRadius = 0;
            this.guna2CheckBox26.CheckedState.BorderThickness = 0;
            this.guna2CheckBox26.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox26.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.guna2CheckBox26.Location = new System.Drawing.Point(260, 684);
            this.guna2CheckBox26.Name = "guna2CheckBox26";
            this.guna2CheckBox26.Size = new System.Drawing.Size(108, 20);
            this.guna2CheckBox26.TabIndex = 46;
            this.guna2CheckBox26.Text = "Fish/Shelifish";
            this.guna2CheckBox26.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CheckBox26.UncheckedState.BorderRadius = 0;
            this.guna2CheckBox26.UncheckedState.BorderThickness = 0;
            this.guna2CheckBox26.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // guna2TextBox4
            // 
            this.guna2TextBox4.BorderThickness = 3;
            this.guna2TextBox4.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox4.DefaultText = "Other";
            this.guna2TextBox4.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox4.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox4.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox4.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox4.FillColor = System.Drawing.Color.WhiteSmoke;
            this.guna2TextBox4.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2TextBox4.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox4.Location = new System.Drawing.Point(284, 1022);
            this.guna2TextBox4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.guna2TextBox4.Name = "guna2TextBox4";
            this.guna2TextBox4.PasswordChar = '\0';
            this.guna2TextBox4.PlaceholderForeColor = System.Drawing.Color.Black;
            this.guna2TextBox4.PlaceholderText = "";
            this.guna2TextBox4.SelectedText = "";
            this.guna2TextBox4.Size = new System.Drawing.Size(223, 43);
            this.guna2TextBox4.TabIndex = 47;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Monotype Corsiva", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(486, 402);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(629, 45);
            this.label7.TabIndex = 48;
            this.label7.Text = "How many times have you had a reaction?*";
            // 
            // guna2CheckBox27
            // 
            this.guna2CheckBox27.AutoSize = true;
            this.guna2CheckBox27.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox27.CheckedState.BorderRadius = 0;
            this.guna2CheckBox27.CheckedState.BorderThickness = 0;
            this.guna2CheckBox27.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox27.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.guna2CheckBox27.Location = new System.Drawing.Point(580, 451);
            this.guna2CheckBox27.Name = "guna2CheckBox27";
            this.guna2CheckBox27.Size = new System.Drawing.Size(66, 20);
            this.guna2CheckBox27.TabIndex = 49;
            this.guna2CheckBox27.Text = "Never";
            this.guna2CheckBox27.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CheckBox27.UncheckedState.BorderRadius = 0;
            this.guna2CheckBox27.UncheckedState.BorderThickness = 0;
            this.guna2CheckBox27.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // guna2CheckBox28
            // 
            this.guna2CheckBox28.AutoSize = true;
            this.guna2CheckBox28.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox28.CheckedState.BorderRadius = 0;
            this.guna2CheckBox28.CheckedState.BorderThickness = 0;
            this.guna2CheckBox28.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox28.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.guna2CheckBox28.Location = new System.Drawing.Point(580, 490);
            this.guna2CheckBox28.Name = "guna2CheckBox28";
            this.guna2CheckBox28.Size = new System.Drawing.Size(61, 20);
            this.guna2CheckBox28.TabIndex = 50;
            this.guna2CheckBox28.Text = "Once";
            this.guna2CheckBox28.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CheckBox28.UncheckedState.BorderRadius = 0;
            this.guna2CheckBox28.UncheckedState.BorderThickness = 0;
            this.guna2CheckBox28.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // guna2CheckBox29
            // 
            this.guna2CheckBox29.AutoSize = true;
            this.guna2CheckBox29.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox29.CheckedState.BorderRadius = 0;
            this.guna2CheckBox29.CheckedState.BorderThickness = 0;
            this.guna2CheckBox29.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox29.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.guna2CheckBox29.Location = new System.Drawing.Point(580, 529);
            this.guna2CheckBox29.Name = "guna2CheckBox29";
            this.guna2CheckBox29.Size = new System.Drawing.Size(121, 20);
            this.guna2CheckBox29.TabIndex = 51;
            this.guna2CheckBox29.Text = "More than once";
            this.guna2CheckBox29.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CheckBox29.UncheckedState.BorderRadius = 0;
            this.guna2CheckBox29.UncheckedState.BorderThickness = 0;
            this.guna2CheckBox29.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Monotype Corsiva", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(549, 570);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(421, 45);
            this.label8.TabIndex = 52;
            this.label8.Text = "When was the last reaction?";
            // 
            // guna2DateTimePicker2
            // 
            this.guna2DateTimePicker2.Checked = true;
            this.guna2DateTimePicker2.FillColor = System.Drawing.Color.Silver;
            this.guna2DateTimePicker2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2DateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.guna2DateTimePicker2.Location = new System.Drawing.Point(580, 618);
            this.guna2DateTimePicker2.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.guna2DateTimePicker2.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.guna2DateTimePicker2.Name = "guna2DateTimePicker2";
            this.guna2DateTimePicker2.Size = new System.Drawing.Size(200, 36);
            this.guna2DateTimePicker2.TabIndex = 53;
            this.guna2DateTimePicker2.Value = new System.DateTime(2023, 1, 7, 10, 19, 25, 856);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Monotype Corsiva", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(572, 670);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(859, 45);
            this.label9.TabIndex = 54;
            this.label9.Text = "What has to happen for you to react to the problem food(s)?";
            // 
            // guna2CheckBox30
            // 
            this.guna2CheckBox30.AutoSize = true;
            this.guna2CheckBox30.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox30.CheckedState.BorderRadius = 0;
            this.guna2CheckBox30.CheckedState.BorderThickness = 0;
            this.guna2CheckBox30.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox30.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.guna2CheckBox30.Location = new System.Drawing.Point(592, 718);
            this.guna2CheckBox30.Name = "guna2CheckBox30";
            this.guna2CheckBox30.Size = new System.Drawing.Size(102, 20);
            this.guna2CheckBox30.TabIndex = 55;
            this.guna2CheckBox30.Text = "Eating Food";
            this.guna2CheckBox30.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CheckBox30.UncheckedState.BorderRadius = 0;
            this.guna2CheckBox30.UncheckedState.BorderThickness = 0;
            this.guna2CheckBox30.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // guna2CheckBox31
            // 
            this.guna2CheckBox31.AutoSize = true;
            this.guna2CheckBox31.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox31.CheckedState.BorderRadius = 0;
            this.guna2CheckBox31.CheckedState.BorderThickness = 0;
            this.guna2CheckBox31.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox31.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.guna2CheckBox31.Location = new System.Drawing.Point(743, 718);
            this.guna2CheckBox31.Name = "guna2CheckBox31";
            this.guna2CheckBox31.Size = new System.Drawing.Size(120, 20);
            this.guna2CheckBox31.TabIndex = 56;
            this.guna2CheckBox31.Text = "Touching Food";
            this.guna2CheckBox31.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CheckBox31.UncheckedState.BorderRadius = 0;
            this.guna2CheckBox31.UncheckedState.BorderThickness = 0;
            this.guna2CheckBox31.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // guna2CheckBox32
            // 
            this.guna2CheckBox32.AutoSize = true;
            this.guna2CheckBox32.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox32.CheckedState.BorderRadius = 0;
            this.guna2CheckBox32.CheckedState.BorderThickness = 0;
            this.guna2CheckBox32.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox32.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.guna2CheckBox32.Location = new System.Drawing.Point(592, 744);
            this.guna2CheckBox32.Name = "guna2CheckBox32";
            this.guna2CheckBox32.Size = new System.Drawing.Size(116, 20);
            this.guna2CheckBox32.TabIndex = 57;
            this.guna2CheckBox32.Text = "Smelling Food";
            this.guna2CheckBox32.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CheckBox32.UncheckedState.BorderRadius = 0;
            this.guna2CheckBox32.UncheckedState.BorderThickness = 0;
            this.guna2CheckBox32.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // guna2CheckBox33
            // 
            this.guna2CheckBox33.AutoSize = true;
            this.guna2CheckBox33.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox33.CheckedState.BorderRadius = 0;
            this.guna2CheckBox33.CheckedState.BorderThickness = 0;
            this.guna2CheckBox33.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox33.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.guna2CheckBox33.Location = new System.Drawing.Point(743, 744);
            this.guna2CheckBox33.Name = "guna2CheckBox33";
            this.guna2CheckBox33.Size = new System.Drawing.Size(18, 17);
            this.guna2CheckBox33.TabIndex = 58;
            this.guna2CheckBox33.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CheckBox33.UncheckedState.BorderRadius = 0;
            this.guna2CheckBox33.UncheckedState.BorderThickness = 0;
            this.guna2CheckBox33.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // guna2TextBox6
            // 
            this.guna2TextBox6.BorderThickness = 3;
            this.guna2TextBox6.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox6.DefaultText = "";
            this.guna2TextBox6.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox6.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox6.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox6.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox6.FillColor = System.Drawing.Color.WhiteSmoke;
            this.guna2TextBox6.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox6.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2TextBox6.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox6.Location = new System.Drawing.Point(767, 745);
            this.guna2TextBox6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.guna2TextBox6.Name = "guna2TextBox6";
            this.guna2TextBox6.PasswordChar = '\0';
            this.guna2TextBox6.PlaceholderForeColor = System.Drawing.Color.Black;
            this.guna2TextBox6.PlaceholderText = "Other";
            this.guna2TextBox6.SelectedText = "";
            this.guna2TextBox6.Size = new System.Drawing.Size(215, 43);
            this.guna2TextBox6.TabIndex = 59;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Monotype Corsiva", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(584, 777);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(1079, 45);
            this.label10.TabIndex = 60;
            this.label10.Text = "How quickly do the signs and symptoms appear after exposure to the foods?";
            // 
            // guna2CheckBox34
            // 
            this.guna2CheckBox34.AutoSize = true;
            this.guna2CheckBox34.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox34.CheckedState.BorderRadius = 0;
            this.guna2CheckBox34.CheckedState.BorderThickness = 0;
            this.guna2CheckBox34.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox34.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.guna2CheckBox34.Location = new System.Drawing.Point(606, 825);
            this.guna2CheckBox34.Name = "guna2CheckBox34";
            this.guna2CheckBox34.Size = new System.Drawing.Size(83, 20);
            this.guna2CheckBox34.TabIndex = 61;
            this.guna2CheckBox34.Text = "Seconds";
            this.guna2CheckBox34.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CheckBox34.UncheckedState.BorderRadius = 0;
            this.guna2CheckBox34.UncheckedState.BorderThickness = 0;
            this.guna2CheckBox34.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // guna2CheckBox35
            // 
            this.guna2CheckBox35.AutoSize = true;
            this.guna2CheckBox35.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox35.CheckedState.BorderRadius = 0;
            this.guna2CheckBox35.CheckedState.BorderThickness = 0;
            this.guna2CheckBox35.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox35.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.guna2CheckBox35.Location = new System.Drawing.Point(868, 825);
            this.guna2CheckBox35.Name = "guna2CheckBox35";
            this.guna2CheckBox35.Size = new System.Drawing.Size(68, 20);
            this.guna2CheckBox35.TabIndex = 62;
            this.guna2CheckBox35.Text = "Minute";
            this.guna2CheckBox35.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CheckBox35.UncheckedState.BorderRadius = 0;
            this.guna2CheckBox35.UncheckedState.BorderThickness = 0;
            this.guna2CheckBox35.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // guna2CheckBox36
            // 
            this.guna2CheckBox36.AutoSize = true;
            this.guna2CheckBox36.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox36.CheckedState.BorderRadius = 0;
            this.guna2CheckBox36.CheckedState.BorderThickness = 0;
            this.guna2CheckBox36.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox36.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.guna2CheckBox36.Location = new System.Drawing.Point(606, 851);
            this.guna2CheckBox36.Name = "guna2CheckBox36";
            this.guna2CheckBox36.Size = new System.Drawing.Size(58, 20);
            this.guna2CheckBox36.TabIndex = 63;
            this.guna2CheckBox36.Text = "Hour";
            this.guna2CheckBox36.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CheckBox36.UncheckedState.BorderRadius = 0;
            this.guna2CheckBox36.UncheckedState.BorderThickness = 0;
            this.guna2CheckBox36.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // guna2CheckBox37
            // 
            this.guna2CheckBox37.AutoSize = true;
            this.guna2CheckBox37.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox37.CheckedState.BorderRadius = 0;
            this.guna2CheckBox37.CheckedState.BorderThickness = 0;
            this.guna2CheckBox37.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox37.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.guna2CheckBox37.Location = new System.Drawing.Point(868, 851);
            this.guna2CheckBox37.Name = "guna2CheckBox37";
            this.guna2CheckBox37.Size = new System.Drawing.Size(54, 20);
            this.guna2CheckBox37.TabIndex = 64;
            this.guna2CheckBox37.Text = "Day";
            this.guna2CheckBox37.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CheckBox37.UncheckedState.BorderRadius = 0;
            this.guna2CheckBox37.UncheckedState.BorderThickness = 0;
            this.guna2CheckBox37.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Monotype Corsiva", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(584, 892);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(720, 45);
            this.label11.TabIndex = 65;
            this.label11.Text = "Please give additional detail about your diet here:";
            // 
            // guna2TextBox8
            // 
            this.guna2TextBox8.BorderThickness = 3;
            this.guna2TextBox8.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox8.DefaultText = "";
            this.guna2TextBox8.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox8.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox8.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox8.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox8.FillColor = System.Drawing.Color.WhiteSmoke;
            this.guna2TextBox8.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox8.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2TextBox8.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox8.Location = new System.Drawing.Point(630, 941);
            this.guna2TextBox8.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.guna2TextBox8.Name = "guna2TextBox8";
            this.guna2TextBox8.PasswordChar = '\0';
            this.guna2TextBox8.PlaceholderForeColor = System.Drawing.Color.Black;
            this.guna2TextBox8.PlaceholderText = "";
            this.guna2TextBox8.SelectedText = "";
            this.guna2TextBox8.Size = new System.Drawing.Size(614, 105);
            this.guna2TextBox8.TabIndex = 67;
            // 
            // guna2Button7
            // 
            this.guna2Button7.BorderColor = System.Drawing.Color.DimGray;
            this.guna2Button7.BorderThickness = 3;
            this.guna2Button7.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button7.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button7.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button7.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button7.FillColor = System.Drawing.Color.Teal;
            this.guna2Button7.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button7.ForeColor = System.Drawing.Color.Black;
            this.guna2Button7.Location = new System.Drawing.Point(1554, 1001);
            this.guna2Button7.Name = "guna2Button7";
            this.guna2Button7.Size = new System.Drawing.Size(125, 45);
            this.guna2Button7.TabIndex = 68;
            this.guna2Button7.Text = "Sumbit";
            // 
            // Dietary_Requirements
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1942, 1085);
            this.Controls.Add(this.guna2Button7);
            this.Controls.Add(this.guna2TextBox8);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.guna2CheckBox37);
            this.Controls.Add(this.guna2CheckBox36);
            this.Controls.Add(this.guna2CheckBox35);
            this.Controls.Add(this.guna2CheckBox34);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.guna2TextBox6);
            this.Controls.Add(this.guna2CheckBox33);
            this.Controls.Add(this.guna2CheckBox32);
            this.Controls.Add(this.guna2CheckBox31);
            this.Controls.Add(this.guna2CheckBox30);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.guna2DateTimePicker2);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.guna2CheckBox29);
            this.Controls.Add(this.guna2CheckBox28);
            this.Controls.Add(this.guna2CheckBox27);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.guna2TextBox4);
            this.Controls.Add(this.guna2CheckBox26);
            this.Controls.Add(this.guna2CheckBox25);
            this.Controls.Add(this.guna2CheckBox24);
            this.Controls.Add(this.guna2CheckBox23);
            this.Controls.Add(this.guna2CheckBox22);
            this.Controls.Add(this.guna2CheckBox21);
            this.Controls.Add(this.guna2CheckBox20);
            this.Controls.Add(this.guna2CheckBox19);
            this.Controls.Add(this.guna2CheckBox18);
            this.Controls.Add(this.guna2CheckBox17);
            this.Controls.Add(this.guna2CheckBox16);
            this.Controls.Add(this.guna2CheckBox15);
            this.Controls.Add(this.guna2CheckBox14);
            this.Controls.Add(this.guna2CheckBox13);
            this.Controls.Add(this.guna2CheckBox12);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.guna2TextBox3);
            this.Controls.Add(this.guna2CheckBox11);
            this.Controls.Add(this.guna2CheckBox10);
            this.Controls.Add(this.guna2CheckBox9);
            this.Controls.Add(this.guna2CheckBox8);
            this.Controls.Add(this.guna2CheckBox7);
            this.Controls.Add(this.guna2CheckBox6);
            this.Controls.Add(this.guna2CheckBox5);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.guna2CheckBox4);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.guna2CheckBox3);
            this.Controls.Add(this.guna2CheckBox2);
            this.Controls.Add(this.guna2CheckBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.guna2Panel2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.guna2DateTimePicker1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.guna2TextBox5);
            this.Controls.Add(this.guna2TextBox2);
            this.Controls.Add(this.guna2TextBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Dietary_Requirements";
            this.Text = "dietary";
            this.guna2Panel2.ResumeLayout(false);
            this.guna2Panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox1;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox2;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox5;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2DateTimePicker guna2DateTimePicker1;
        private System.Windows.Forms.ComboBox comboBox1;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2ControlBox guna2ControlBox4;
        private Guna.UI2.WinForms.Guna2ControlBox guna2ControlBox5;
        private Guna.UI2.WinForms.Guna2ControlBox guna2ControlBox6;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2CheckBox guna2CheckBox1;
        private Guna.UI2.WinForms.Guna2CheckBox guna2CheckBox2;
        private Guna.UI2.WinForms.Guna2CheckBox guna2CheckBox3;
        private System.Windows.Forms.Label label4;
        private Guna.UI2.WinForms.Guna2CheckBox guna2CheckBox4;
        private System.Windows.Forms.Label label5;
        private Guna.UI2.WinForms.Guna2CheckBox guna2CheckBox5;
        private Guna.UI2.WinForms.Guna2CheckBox guna2CheckBox6;
        private Guna.UI2.WinForms.Guna2CheckBox guna2CheckBox7;
        private Guna.UI2.WinForms.Guna2CheckBox guna2CheckBox8;
        private Guna.UI2.WinForms.Guna2CheckBox guna2CheckBox9;
        private Guna.UI2.WinForms.Guna2CheckBox guna2CheckBox10;
        private Guna.UI2.WinForms.Guna2CheckBox guna2CheckBox11;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox3;
        private System.Windows.Forms.Label label6;
        private Guna.UI2.WinForms.Guna2CheckBox guna2CheckBox12;
        private Guna.UI2.WinForms.Guna2CheckBox guna2CheckBox13;
        private Guna.UI2.WinForms.Guna2CheckBox guna2CheckBox14;
        private Guna.UI2.WinForms.Guna2CheckBox guna2CheckBox15;
        private Guna.UI2.WinForms.Guna2CheckBox guna2CheckBox16;
        private Guna.UI2.WinForms.Guna2CheckBox guna2CheckBox17;
        private Guna.UI2.WinForms.Guna2CheckBox guna2CheckBox18;
        private Guna.UI2.WinForms.Guna2CheckBox guna2CheckBox19;
        private Guna.UI2.WinForms.Guna2CheckBox guna2CheckBox20;
        private Guna.UI2.WinForms.Guna2CheckBox guna2CheckBox21;
        private Guna.UI2.WinForms.Guna2CheckBox guna2CheckBox22;
        private Guna.UI2.WinForms.Guna2CheckBox guna2CheckBox23;
        private Guna.UI2.WinForms.Guna2CheckBox guna2CheckBox24;
        private Guna.UI2.WinForms.Guna2CheckBox guna2CheckBox25;
        private Guna.UI2.WinForms.Guna2CheckBox guna2CheckBox26;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox4;
        private System.Windows.Forms.Label label7;
        private Guna.UI2.WinForms.Guna2CheckBox guna2CheckBox27;
        private Guna.UI2.WinForms.Guna2CheckBox guna2CheckBox28;
        private Guna.UI2.WinForms.Guna2CheckBox guna2CheckBox29;
        private System.Windows.Forms.Label label8;
        private Guna.UI2.WinForms.Guna2DateTimePicker guna2DateTimePicker2;
        private System.Windows.Forms.Label label9;
        private Guna.UI2.WinForms.Guna2CheckBox guna2CheckBox30;
        private Guna.UI2.WinForms.Guna2CheckBox guna2CheckBox31;
        private Guna.UI2.WinForms.Guna2CheckBox guna2CheckBox32;
        private Guna.UI2.WinForms.Guna2CheckBox guna2CheckBox33;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox6;
        private System.Windows.Forms.Label label10;
        private Guna.UI2.WinForms.Guna2CheckBox guna2CheckBox34;
        private Guna.UI2.WinForms.Guna2CheckBox guna2CheckBox35;
        private Guna.UI2.WinForms.Guna2CheckBox guna2CheckBox36;
        private Guna.UI2.WinForms.Guna2CheckBox guna2CheckBox37;
        private System.Windows.Forms.Label label11;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox8;
        private Guna.UI2.WinForms.Guna2Button guna2Button7;
    }
}