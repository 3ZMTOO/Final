﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp11
{
    public partial class loading : Form
    {
        public loading()
        {
            InitializeComponent();
        }
        int startpos = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            startpos += 1;
            progress.Value = startpos;
            label3.Text = startpos + "%";
            if(progress.Value == 100)
            {
                progress.Value = 0;
                timer1.Stop();
                Form1 f = new Form1();
                f.Show();
                this.Hide();
            }
            
        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void guna2PictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void loading_Load(object sender, EventArgs e)
        {
            timer1.Start();
        }
    }
}
